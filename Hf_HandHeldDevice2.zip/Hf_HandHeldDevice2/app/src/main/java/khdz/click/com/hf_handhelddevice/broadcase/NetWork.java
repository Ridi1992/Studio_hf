package khdz.click.com.hf_handhelddevice.broadcase;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.net.Inet4Address;
import java.net.InetAddress;

import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.activity.Setting_Activity;
import khdz.click.com.hf_handhelddevice.activity.Socket_Activity;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.widget.Toast;

@SuppressLint("NewApi")
public class NetWork extends BroadcastReceiver {
	 ConnectivityManager mConnectivityManager=null;
	 public static boolean NetworkState=false;
    @SuppressWarnings("deprecation")
	@Override
    public void onReceive(Context context, Intent intent) {
        
    	  mConnectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
    	  final String action = intent.getAction(); 
    	  
          if (ConnectivityManager.CONNECTIVITY_ACTION.equals(action)) {
              NetworkInfo info = intent.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
              if(info == null){
                //Toast.makeText(context, "Network !", Toast.LENGTH_LONG).show();
              }
              int type = info.getType();
              State st;
              android.net.NetworkInfo.State state = info.getState(); //�õ���ʱ������״̬
              if(type == ConnectivityManager.TYPE_ETHERNET){
                  if(state == android.net.NetworkInfo.State.CONNECTED){   //�ж�����״̬
                    Toast.makeText(context, "Network connection successfully!", Toast.LENGTH_SHORT).show();
                	  NetworkState=true;
                      toActivity(context);
                    
                  } else if(state == android.net.NetworkInfo.State.DISCONNECTED){
                	  NetworkState=false; 
                	//  Log.e(TAG, "android.net.NetworkInfo.State.DISCONNECTED");
                      Toast.makeText(context, "Network connection fail !", Toast.LENGTH_SHORT).show();
                  }
              }else if(type == ConnectivityManager.TYPE_MOBILE){    //�ж���������
                  if(state == android.net.NetworkInfo.State.CONNECTED){   //�ж�����״̬
                     // Log.e(TAG, "android.net.NetworkInfo.State.CONNECTED");
                  } else if(state == android.net.NetworkInfo.State.DISCONNECTED){
                     // Log.e(TAG, "android.net.NetworkInfo.State.DISCONNECTED");
                  }
              }else if(type == ConnectivityManager.TYPE_WIFI){ //WiFi
                  if(state == android.net.NetworkInfo.State.CONNECTED){   //�ж�����״̬
                      //Toast.makeText(context, "Wifi connection successfully!", Toast.LENGTH_LONG).show();
                      
                	  //Log.e(TAG, "android.net.NetworkInfo.State.CONNECTED");
                  } else if(state == android.net.NetworkInfo.State.DISCONNECTED){
                     // Toast.makeText(context, "Wifi connection fail !", Toast.LENGTH_LONG).show();
                      
                	  
                	  // Log.e(TAG, "android.net.NetworkInfo.State.DISCONNECTED");
                  }
              }
          } else {
            //  Log.e(TAG, "other android.net.NetworkInfo.State");
          }
      
   

        }
   
   
   
	private void toActivity(Context context) {
		//�ж��ϴ��Ƿ�����
        SharedPreferences  preferences =MyApplication.context.getSharedPreferences("ServerSocket", Context.MODE_PRIVATE);
        
        if(preferences==null){//first connected  serverIP="";
        	Toast.makeText(context, "serverIP ===", Toast.LENGTH_LONG).show();
        	Intent myIntent = new Intent(context, Setting_Activity.class);//Setting_Activity
            myIntent.putExtra("Tag", "net");
            myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(myIntent);
        }else{
        //	Toast.makeText(context, "Network connection successfully!", Toast.LENGTH_LONG).show();
        	 String   serverIP = preferences.getString("ip", "");
             if(serverIP.equals("")){//first connected  serverIP="";
                 Intent myIntent = new Intent(context, Setting_Activity.class);//Setting_Activity
                 myIntent.putExtra("Tag", "net");
                 myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                 context.startActivity(myIntent);
             }else {
                 Intent myIntent = new Intent(context, Socket_Activity.class);
                 myIntent.putExtra("serverIP",serverIP);
                 myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                 context.startActivity(myIntent);

             }
        }
        
        
        
       
	}

   
}
