package khdz.click.com.hf_handhelddevice.data;

import java.io.Serializable;
import java.util.List;


/**
 * Created by Administrator on 2017/9/12.
 */

public class CollectiveCardInfo  implements Serializable{
	private  int  collective_carder_id;
    private  String  carderNumber;
    private  List<CollectivePersonInfo>  collectivePersonInfo;
    private  CollectiveCardAuthorizationDate collectiveDateInfo;
    private  List<CollectiveCardAuthorizationTime>  collectiveTimeInfo;
	public int getCollective_carder_id() {
		return collective_carder_id;
	}
	public void setCollective_carder_id(int collective_carder_id) {
		this.collective_carder_id = collective_carder_id;
	}
	public String getCarderNumber() {
		return carderNumber;
	}
	public void setCarderNumber(String carderNumber) {
		this.carderNumber = carderNumber;
	}
	public List<CollectivePersonInfo> getCollectivePersonInfo() {
		return collectivePersonInfo;
	}
	public void setCollectivePersonInfo(
			List<CollectivePersonInfo> collectivePersonInfo) {
		this.collectivePersonInfo = collectivePersonInfo;
	}
	public CollectiveCardAuthorizationDate getCollectiveDateInfo() {
		return collectiveDateInfo;
	}
	public void setCollectiveDateInfo(
			CollectiveCardAuthorizationDate collectiveDateInfo) {
		this.collectiveDateInfo = collectiveDateInfo;
	}
	public List<CollectiveCardAuthorizationTime> getCollectiveTimeInfo() {
		return collectiveTimeInfo;
	}
	public void setCollectiveTimeInfo(
			List<CollectiveCardAuthorizationTime> collectiveTimeInfo) {
		this.collectiveTimeInfo = collectiveTimeInfo;
	}
	
    
}
