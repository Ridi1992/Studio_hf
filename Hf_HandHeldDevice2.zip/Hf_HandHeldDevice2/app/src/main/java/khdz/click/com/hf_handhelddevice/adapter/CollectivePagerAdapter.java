package khdz.click.com.hf_handhelddevice.adapter;

import java.util.ArrayList;
import java.util.List;

import khdz.click.com.hf_handhelddevice.FileDataHelp;
import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;
import khdz.click.com.hf_handhelddevice.tools.Utils;

import android.graphics.Bitmap;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class CollectivePagerAdapter extends PagerAdapter {
	
	private ArrayList<View> mViewList;
	private List<PersonInfo> dadaList;
	public CollectivePagerAdapter(ArrayList<View> list,List<PersonInfo> dadaList){
		mViewList = list;
		this.dadaList=dadaList;
	}

	@Override
	public int getCount() {
		if (mViewList != null) {
			return mViewList.size();
		}
		return 0;
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == arg1;
	}
	
	@Override
	public Object instantiateItem(ViewGroup container, int position) {
		
		int index = position%mViewList.size();
		View view = mViewList.get(index);
		container.addView(view);
		
	
		PersonInfo info=	dadaList.get(position);
		
		TextView title=(TextView)view.findViewById(R.id.title);
		ImageView photo=(ImageView)view.findViewById(R.id.photo);
		TextView name=(TextView)view.findViewById(R.id.name);
		TextView departmentName=(TextView)view.findViewById(R.id.department_name);
		TextView principalName=(TextView)view.findViewById(R.id.principal_name);
		TextView idCard=(TextView)view.findViewById(R.id.id_card);	
		TextView time=(TextView)view.findViewById(R.id.time);
		
		title.setText(R.string.collectionCarder);
		//title.setTextSize(25);
		String wname = MyApplication.DeCode(info.getName());
        name.setText(wname);
        idCard.setText(info.getId_card());
        departmentName.setText(info.getPrincipal_name());
        principalName.setText(info.getDepart_name());
        time.setText(Utils.getDateTime());
        String path = MyApplication.getFileNameIsPhoto(info.getPerson_iris_sn());
        if (path.equals("")) {
        	photo.setBackgroundResource(R.mipmap.hotelimage);
        }
        Bitmap btm = Utils.getLocalBitmap(path);
        if (btm != null) {
        	photo.setImageBitmap(btm);
        }
		
		//TextView tex=(TextView) view.findViewById(R.id.ridiImage);  
		//tex.setText(info.getPerson_sn());
		return view;
	}
	
	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		View view = mViewList.get(position);
		
		container.removeView(view);
		
	}
	
}
