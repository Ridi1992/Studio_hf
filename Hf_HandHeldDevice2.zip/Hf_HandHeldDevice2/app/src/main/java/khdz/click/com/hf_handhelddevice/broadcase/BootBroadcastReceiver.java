package khdz.click.com.hf_handhelddevice.broadcase;





import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.activity.ScreenDormancyActivity;
import khdz.click.com.hf_handhelddevice.activity.Setting_Activity;
import khdz.click.com.hf_handhelddevice.activity.WelcomeActivity;
import khdz.click.com.hf_handhelddevice.service.DeviceService;
import khdz.click.com.hf_handhelddevice.tools.Utils;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.WindowManager;
//import android.support.annotation.RequiresApi;
import android.widget.Toast;

/**
 * Created by Administrator on 2017/8/1.
 */

public class BootBroadcastReceiver  extends BroadcastReceiver {
	  final String SYSTEM_DIALOG_REASON_KEY = "reason";
      final String SYSTEM_DIALOG_REASON_RECENT_APPS = "recentapps";
      final String SYSTEM_DIALOG_REASON_HOME_KEY = "homekey";
	 public static WakeLock wakeLock = null;
	 public static PowerManager pm;
	@Override
    public void onReceive(Context context, Intent intent) {
        switch (intent.getAction()){
       
        case Intent.ACTION_SCREEN_ON:
            // The tail
        	// Log.e(" screen  on", "");
        	
            break;
        case Intent.ACTION_SCREEN_OFF:
//        	 acquireWakeLock();//WakeLock  ScreenDormancyActivity
//	         Intent myintent = new Intent(context, ScreenDormancyActivity.class);
//	         myintent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//             context.startActivity(myintent);
     		// Lock screen
            break;
            case Intent.ACTION_USER_PRESENT:
//            	if(BootBroadcastReceiver.wakeLock!=null&&BootBroadcastReceiver.wakeLock.isHeld()){
//                	BootBroadcastReceiver.wakeLock.release();
//            	}
//            	ScreenDormancyActivity dd=new ScreenDormancyActivity();
//            	dd.getClose();

                // Unlock the screen
                //因为WelcomeActivity实列只有一个，屏幕解锁后，不会创建新的WelcomeActivity
                Intent ootStartIntent = new Intent(context, WelcomeActivity.class);
                ootStartIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(ootStartIntent);
                
                break;
            case Intent.ACTION_SHUTDOWN:// boot down
            	Intent sendToservice = new Intent(context,DeviceService.class);  //用于发送指令
	   		    sendToservice.putExtra("cmd", ""); 
	   		    sendToservice.putExtra("activity", "stopflag");
	   		    context.startService(sendToservice); 
                break;
            case Intent.ACTION_BOOT_COMPLETED://Boot up
            	 Intent tStartIntent = new Intent(context, WelcomeActivity.class);
            	 tStartIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                 context.startActivity(tStartIntent);
                break;
              
                
                
        };

    }
    
    
    private void acquireWakeLock() {
    	  if (null == wakeLock) {
    	   pm = (PowerManager)MyApplication.context. getSystemService(Context.POWER_SERVICE);
    	   wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK
    	     | PowerManager.ON_AFTER_RELEASE, getClass()
    	     .getCanonicalName());
    	   if (null != wakeLock) {
    	    wakeLock.acquire();
    	   }
    	  }
    }
}
