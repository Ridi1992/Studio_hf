package khdz.click.com.hf_handhelddevice.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.data.PersonIdentifyInfo;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;
import khdz.click.com.hf_handhelddevice.db.DBService;
import khdz.click.com.hf_handhelddevice.tools.Timetool;
import khdz.click.com.hf_handhelddevice.tools.Utils;

import static khdz.click.com.hf_handhelddevice.activity.WelcomeActivity.FLAG_HOMEKEY_DISPATCHED;

public class ShowCarderInfo_Activity extends Activity {
	
	private ImageView photh;
	private TextView title,name,departmentName,principalName,idCard, time,state;
	private PersonInfo infobean;
	private PersonIdentifyInfo IdentifyInfoBean;
	private DBService server;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//Shielding home button
        setContentView(R.layout.activity_identify_detail_);
       initView();
       sendBroadcast_closeBackgroundActivity();

//        topLy.getBackground().setAlpha(80);
        infobean = (PersonInfo) getIntent().getSerializableExtra("bean");
        save(infobean);
        initView(infobean);
        server = new DBService(this);
        IdentifyInfoBean = saveIdenfityLog(infobean);
        boolean insert = server.insertIdentifyData(IdentifyInfoBean);

       

    }

    @Override
	protected void onStart() {
		super.onStart();
		Utils.playerVoice(this, 0);
    }
	
	@Override
	protected void onResume() {
		super.onResume();
		 Timer timer = new Timer();
	        timer.schedule(new TimerTask() {
	            @Override
	            public void run() {
	                Intent intent = new Intent();
	                intent.setClass(ShowCarderInfo_Activity.this, WelcomeActivity.class);
	                startActivity(intent);
	                finish();

	            }
	        }, 1000 * 2);
	}

	private void sendBroadcast_closeBackgroundActivity() {
    	 //if compareCarder succeed,sendBroadcast,close Background Activity
        Intent intent = new Intent();
        intent.setAction("closeBackgroundActivity");
        sendBroadcast(intent);
		
	}
	private void initView() {
		title=(TextView)findViewById(R.id.title);
		title.setText(R.string.IdentifyStatus);
		photh=(ImageView)findViewById(R.id.photh);
		name=(TextView)findViewById(R.id.name);
		departmentName=(TextView)findViewById(R.id.department_name);
		principalName=(TextView)findViewById(R.id.principal_name);
		idCard=(TextView)findViewById(R.id.id_card);
		time=(TextView)findViewById(R.id.time);
		state=(TextView)findViewById(R.id.state);
	}
	@Override
    protected void onDestroy() {
        super.onDestroy();
        Utils.stopVoice(this);
    }

    private PersonIdentifyInfo saveIdenfityLog(PersonInfo infobean) {
        PersonIdentifyInfo indentify = new PersonIdentifyInfo();
        indentify.setPerson_sn(infobean.getPerson_sn());
        indentify.setName(MyApplication.EnCode(infobean.getName()));
        indentify.setSex(infobean.getSex());
        indentify.setId_card(MyApplication.EnCode(infobean.getId_card()));//
        indentify.setWork_sn(MyApplication.EnCode(infobean.getWork_sn()));
        indentify.setDepart_name(infobean.getDepart_name());
        indentify.setPrincipal_name(infobean.getPrincipal_name());
        indentify.setPerson_iris_sn(infobean.getPerson_iris_sn());
        indentify.setPhoto_flag(infobean.getPhoto_flag());

        indentify.setState(MyApplication.SUCCEED_STATE);
        indentify.setTime(Utils.getDateTime());
        indentify.setLong_time(Timetool.getTime(Utils.getDateTime()));
        return indentify;
    }

    private void initView(PersonInfo info) {
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) photh.getLayoutParams();
        LinearLayout.LayoutParams lp;
        if(MyApplication.GLOBAL_SCREEN_ORIENTATION_FLAG){//SCREEN_ORIENTATION_PORTRAIT
           lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            photh.setLayoutParams(lp);
        }else{//SCREEN_ORIENTATION_LANDSCAPE
            params.width = (WelcomeActivity.screenHeigh/4)*3;
            lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, params.height);
            photh.setLayoutParams(lp);
        }
        String wname = MyApplication.DeCode(info.getName());
        name.setText(wname);
        idCard.setText(info.getId_card());
        departmentName.setText(info.getPrincipal_name());
        principalName.setText(info.getDepart_name());
        time.setText(Utils.getDateTime());
        state.setText(R.string.identify_sussess);
        String path = MyApplication.getFileNameIsPhoto(info.getPerson_iris_sn());
        // String path = "/storage/sdcard0/Android/P000002_imagejpg" ;
        if (path.equals("")) {
        	photh .setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT));

            photh.setBackgroundResource(R.mipmap.hotelimage);
        }
        Bitmap btm = Utils.getLocalBitmap(path);
        if (btm != null) {
            photh.setImageBitmap(btm);
        }
    }

    public void save(PersonInfo knownBean) {
    	String devices="";
    	if(Utils.getLocalIpAddress()==null){
         	SharedPreferences preferences = MyApplication.getContext().getSharedPreferences("LocalIpAddress", Context.MODE_PRIVATE);
            if(!preferences.getString("localIp","").equals("")){
                devices = preferences.getString("localIp","");
            }else{
                devices = MyApplication.getIMEI();
            }
    	}else{
    		devices=Utils.getLocalIpAddress();
    	}
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("person_sn", knownBean.getPerson_sn());//���˿�ע����Աperson_sn
            jsonObject.put("recog_time", Utils.getDateTime());//��ǰʶ��ʱ��
            jsonObject.put("device_sn", devices);//��ǰʶ���豸
            jsonObject.put("recog_pattern", MyApplication.RECOG_PATTERN);//ѡ��ʶ��ģʽ  2=���ܿ�
            jsonObject.put("state", MyApplication.SUCCEED_STATE);//ʶ��״̬  �ɹ�=0, ʧ��=1
        } catch (JSONException e) {
            e.printStackTrace();}
        String bb = jsonObject + "\n";//����д�뱾��path�ļ���һ��ʶ���¼Ϊһ�У���ʽΪJSON��ʽ�ַ���
        byte[] mm = new byte[0];
        try {
            mm = bb.toString().getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(MyApplication.PERSIN_IDENTIFY_FILE, true);
            try {
                fos.write(mm);

                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }


    }


}
