package khdz.click.com.hf_handhelddevice.data;

import java.io.Serializable;


/**
 * Created by Administrator on 2017/7/18.
 */

public class PersonDeviceInfo    implements Serializable{
    int id;
    String person_sn;
    String   person_group;
    String person_assignmode;
    String   camera_sn;
    String at_position;
    String   camera_name;

    public String getAt_position() {
        return at_position;
    }

    public void setAt_position(String at_position) {
        this.at_position = at_position;
    }

    public String getCamera_name() {
        return camera_name;
    }

    public void setCamera_name(String camera_name) {
        this.camera_name = camera_name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPerson_sn() {
        return person_sn;
    }

    public void setPerson_sn(String person_sn) {
        this.person_sn = person_sn;
    }

    public String getPerson_group() {
        return person_group;
    }

    public void setPerson_group(String person_group) {
        this.person_group = person_group;
    }

    public String getPerson_assignmode() {
        return person_assignmode;
    }

    public void setPerson_assignmode(String person_assignmode) {
        this.person_assignmode = person_assignmode;
    }

    public String getCamera_sn() {
        return camera_sn;
    }

    public void setCamera_sn(String camera_sn) {
        this.camera_sn = camera_sn;
    }
}
