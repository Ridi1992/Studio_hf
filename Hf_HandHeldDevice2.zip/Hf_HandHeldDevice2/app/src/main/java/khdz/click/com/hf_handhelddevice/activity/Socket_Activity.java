package khdz.click.com.hf_handhelddevice.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;

import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.broadcase.NetWork;
import khdz.click.com.hf_handhelddevice.broadcase.SocketReceiver;
import khdz.click.com.hf_handhelddevice.thread.MyClient;
import khdz.click.com.hf_handhelddevice.tools.Utils;

import static khdz.click.com.hf_handhelddevice.activity.WelcomeActivity.FLAG_HOMEKEY_DISPATCHED;

/**
 * Matters needing attention
 * <p>
 * 1.Change the IP address on the broadcast notification whenever you change the IP address of the server.
 * Keep the client open, active link server
 * <p>
 * 2. Close the last client link for every change of iP address.Otherwise the port is in the occupied state
 */
public class Socket_Activity extends Activity {
    public ProgressDialog m_Dialog = null;

    static TextView text, text1, text2, text3, text4, text5, text6;
    String ServerIP = "";
    TextView title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//Shielding home button
        setContentView(R.layout.activity_socket);
        title = (TextView) findViewById(R.id.title);
        ServerIP = getIntent().getStringExtra("serverIP");
        initView();
        Resources res =getResources();
    	String[] netSetting=res.getStringArray(R.array.internetSeetting);
        m_Dialog = ProgressDialog.show(this, netSetting[4], netSetting[5] + ServerIP, true);
        m_Dialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        SocketReceiver.socket_ActivityContextList.add((Activity) Socket_Activity.this);
        if (NetWork.NetworkState) {
            if (MyClient.socketList.size() > 0) {//
                try {
                    MyClient.socketList.get(0).close();
                    LinkServer(ServerIP);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                LinkServer(ServerIP);
            }
        	

        } else {//no network
            Intent myIntent = new Intent(this, Setting_Activity.class);
            myIntent.putExtra("Tag", "net");
            myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(myIntent);
            this.finish();
        }


    }

    private void initView() {
        title = (TextView) findViewById(R.id.title);
        title.setText(R.string.connectedServer);
        text = (TextView) findViewById(R.id.text);
        text.setText(R.string.toconnect);
        text1 = (TextView) findViewById(R.id.text1);
        text2 = (TextView) findViewById(R.id.text2);
        text3 = (TextView) findViewById(R.id.text3);
        text4 = (TextView) findViewById(R.id.text4);
        text5 = (TextView) findViewById(R.id.text5);
        text6 = (TextView) findViewById(R.id.text6);

    }

   //  http _ socket Thread
    private static Socket client;
    private static final ThreadLocal<Socket> threadConnect = new ThreadLocal<Socket>(); 
	  
    private void LinkServer(String serverIP) {
        MyClient myClientTest = new MyClient(serverIP);
        Thread thread = new Thread(myClientTest);
        thread.start();
        
    	
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        m_Dialog.dismiss();
    }

    public static class SocketHandler extends Handler {
        String massage = "";

        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
           // if(msg!=null) {
                switch (msg.what) {
                    case 0:
                        massage = msg.getData().getString("text1");
                        text.setText(massage);
                        break;
//                    case 1:
//                        //massage= msg.getData().getString("text1");
//                        text1.setText(R.string.file1);
//                        break;
//                    case 2:
//                        text2.setText(R.string.file2);
//                        break;
//                    case 3:
//                        text3.setText(R.string.file3);
//                        break;
//                    case 4:
//                        text4.setText(R.string.file4);
//                        break;
//                    case 5:
//                        text5.setText(R.string.file5);
//                    case 6:
//                    case 7:
//                        text6.setText(R.string.SendDataOver);
//                        break;

//                }

            }

        }
    }


}
