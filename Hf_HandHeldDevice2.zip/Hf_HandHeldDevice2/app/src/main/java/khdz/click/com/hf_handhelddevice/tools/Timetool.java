package khdz.click.com.hf_handhelddevice.tools;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


import android.text.format.Time;
import android.util.Log;
/**
 * Created by Administrator on 2017/6/30.
 */

public class Timetool {/**
 
  
  
    
    /**
     *鏃堕棿杞崲鎴愭椂闂存埑
     */
    public static long  getlongTimeSkew(String user_time) {
        String re_time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");//
        Date d;
        long ln = 0;
        try {
            d = sdf.parse(user_time);
            ln = d.getTime();
            String str = String.valueOf(ln);
            re_time = str.substring(0, 10);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        // return Integer.parseInt(re_time);
        return ln;
    }
    public  static String getDateTime() {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd HH:mm E");
        return sdf.format(new Date());
    }
    public  static String getDateTimeCross() {
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm E");
        return sdf.format(new Date());
    }
    public static long  getlongTimeCross(String user_time) {
        String re_time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");//
        Date d;
        long ln = 0;
        try {
            d = sdf.parse(user_time);
            ln = d.getTime();
            String str = String.valueOf(ln);
            re_time = str.substring(0, 10);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        // return Integer.parseInt(re_time);
        return ln;
    }
    /**
     *鏃堕棿杞崲鎴愭椂闂存埑
     */
    public static long  getTime(String user_time) {
        String re_time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");//
        Date d;
        long ln = 0;
        try {
            d = sdf.parse(user_time);
            ln = d.getTime();
            String str = String.valueOf(ln);
            re_time = str.substring(0, 10);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        // return Integer.parseInt(re_time);
        return ln;
    }
    /**
     *鏃堕棿杞崲鎴愭椂闂存埑
     */
    public static long  getTime1(String user_time) {
        String re_time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date d;
        try {
            d = sdf.parse(user_time);
            long l = d.getTime();
            String str = String.valueOf(l);
            re_time = str.substring(0, 10);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return Integer.parseInt(re_time);
    }

    public static long  getTimeF(String user_time) {
        String re_time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");//
        Date d;
        long ln = 0;
        try {
            d = sdf.parse(user_time);
            ln = d.getTime();
            String str = String.valueOf(ln);
            re_time = str.substring(0, 10);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        // return Integer.parseInt(re_time);
        return ln;
    }
    public static long  getTimeH(String user_time) {
        String re_time = null;
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");//
        Date d;
        long ln = 0;
        try {
            d = sdf.parse(user_time);
            ln = d.getTime();
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return ln;
    }










    /**
     * 璋冩鏂规硶杈撳叆鎵�杞崲鐨勬椂闂磋緭鍏ヤ緥濡傦紙"2014-06-14-16-09-00"锛夎繑鍥炴椂闂存埑
     *
     * @param time
     * @return
     */
    public static String dataOne(String time) {
        SimpleDateFormat sdr = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss", Locale.CHINA);
        Date date;
        String times = null;
        try {
            date = sdr.parse(time);
            long l = date.getTime();
            String stf = String.valueOf(l);
            times = stf.substring(0, 10);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return times;
    }








}
