package khdz.click.com.hf_handhelddevice.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import khdz.click.com.hf_handhelddevice.R;


/**
 * Created by Administrator on 2017-12-18.
 */

public abstract class LvCommonAdapter<T> extends BaseAdapter {
    protected LayoutInflater mInflater;
    protected Context mContext;
    protected List<T> mDatas;
    protected final int mItemLayoutId;
    public LvCommonAdapter(Context context, int itemLayoutId, List<T> mDatas ) {
        this.mContext = context;
        this.mInflater = LayoutInflater.from(mContext);
        this.mDatas = mDatas;
        this.mItemLayoutId = itemLayoutId;
    }
    @Override
    public int getCount()
    {
        return mDatas.size();
    }

    @Override
    public T getItem(int position)
    {
        return mDatas.get(position);
    }

    @Override
    public long getItemId(int position) {return position;}

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ViewHolder viewHolder = getViewHolder(position, convertView,parent);
        convert(viewHolder, position,getItem(position));
        return viewHolder.getConvertView();

    }

    public abstract void convert(ViewHolder helper,int position, T item);
    
    
    private ViewHolder getViewHolder(int position, View convertView, ViewGroup parent) {
        return ViewHolder.get(mContext, convertView, parent, mItemLayoutId,
                position);
    }


    public static class ViewHolder  {
        private final SparseArray<View> mViews;
        private int mPosition;
        private View mConvertView;
        private ViewHolder(Context context, ViewGroup parent, int layoutId, int position) {
            this.mPosition = position;
            this.mViews = new SparseArray<View>();
            mConvertView = LayoutInflater.from(context).inflate(layoutId, parent,false);
            mConvertView.setTag(this);
        }

       
        public static ViewHolder get(Context context, View convertView, ViewGroup parent, int layoutId, int position){
            if (convertView == null) {
                return new ViewHolder(context, parent, layoutId, position);
            }
            return (ViewHolder) convertView.getTag();
        }

        public View getConvertView()
        {
            return mConvertView;
        }

       
        public <T extends View> T getView(int viewId){
            View view = mViews.get(viewId);
            if (view == null) {
                view = mConvertView.findViewById(viewId);
                mViews.put(viewId, view);
            }
            return (T) view;
        }

       
        public ViewHolder setText(int viewId, String text)
        {
            TextView view = getView(viewId);
            view.setText(text);
            return this;
        }
        public ViewHolder setText(int viewId, int text)
        {
            TextView view = getView(viewId);
            view.setText(text);
            return this;
        }
        
        
        
        public ViewHolder setBcolor(int viewId, String color){
        	LinearLayout view = getView(viewId);
            view.setBackgroundColor(Color.parseColor(color));
            return this;
        }

        
        public ViewHolder setImageResource(int viewId, int drawableId) {
            ImageView view = getView(viewId);
            view.setImageResource(drawableId);

            return this;
        }

       
        public ViewHolder setImageBitmap(int viewId, Bitmap bm)
        {
            ImageView view = getView(viewId);
            view.setImageBitmap(bm);
            return this;
        }

       
        public ViewHolder setImageByUrl(int viewId, String url) {
            // ImageLoader.getInstance(3, Type.LIFO).loadImage(url, (ImageView) getView(viewId));
            // Glide.with(context).load(url).into(view);

            return this;
        }

        public int getPosition()
        {
            return mPosition;
        }

    }






}