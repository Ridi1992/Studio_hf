package khdz.click.com.hf_handhelddevice.activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import khdz.click.com.hf_handhelddevice.FileDataHelp;
import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.adapter.LvCommonAdapter;
import khdz.click.com.hf_handhelddevice.adapter.LvCommonAdapter.ViewHolder;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationTime;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardInfo;
import khdz.click.com.hf_handhelddevice.data.CollectivePersonInfo;
import khdz.click.com.hf_handhelddevice.data.PersonIdentifyInfo;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;
import khdz.click.com.hf_handhelddevice.db.DBService;
import khdz.click.com.hf_handhelddevice.tools.ListUtil;
import khdz.click.com.hf_handhelddevice.tools.Timetool;
import khdz.click.com.hf_handhelddevice.tools.Utils;

import static khdz.click.com.hf_handhelddevice.activity.WelcomeActivity.FLAG_HOMEKEY_DISPATCHED;

public class ShowCollectiveInfo_Activity extends Activity {
    private TextView enterIntoNumber,collectionCarderNumber, mydate;
    private ListView personlist_view,timeList_view;
    private LinearLayout dateLy;
    private LvCommonAdapter adapter;
    private CollectiveCardInfo collectivedata;
    private DBService server;
    private String  PageTag;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//Shielding home button
        setContentView(R.layout.activity_show_collection_info);

        collectivedata = (CollectiveCardInfo) getIntent().getSerializableExtra("CollectiveCardInfo");
        PageTag= getIntent().getStringExtra("PageTag");



        saveCollectivePeople(collectivedata);
        initView();
        initViewData(collectivedata);
        //  if compare collective carder succeed,sendBroadcast,close Background Activity
        Intent intent = new Intent();
        intent.setAction("closeBackgroundActivity");
        sendBroadcast(intent);

    }
    private void initView() {
        // find view
        enterIntoNumber=(TextView)findViewById(R.id.enterIntoNumber);
        collectionCarderNumber=(TextView)findViewById(R.id.collectionCarderNumber);
        mydate=(TextView)findViewById(R.id.mydate);
        personlist_view=(ListView)findViewById(R.id.personlist);
        dateLy=(LinearLayout)findViewById(R.id.date_ly);
        timeList_view=(ListView)findViewById(R.id.timelist);


    }
    private void saveCollectivePeople(CollectiveCardInfo collectivedata2) {
        if(collectivedata!=null&&collectivedata.getCollectivePersonInfo()!=null){
            for(int i=0;i<collectivedata.getCollectivePersonInfo().size();i++){
                String person_sn=  collectivedata.getCollectivePersonInfo().get(i).getPerson_sn();
                if(person_sn!=null&&!person_sn.equals("")){
                    PersonInfo personInfo=   FileDataHelp.compareCard(MyApplication.PERSIN_INFO_FILE,person_sn);
                    PersonIdentifyInfo logdata= saveLogs( personInfo);
                    server=new DBService(this);
                    boolean issave= server.insertIdentifyData(logdata);
                }
            }
        }
    }
    private PersonIdentifyInfo saveLogs(PersonInfo infobean) {
        PersonIdentifyInfo indentify = new PersonIdentifyInfo();
        indentify.setPerson_sn(infobean.getPerson_sn());
        indentify.setName(MyApplication.EnCode(infobean.getName()));
        indentify.setSex(infobean.getSex());
        indentify.setId_card(MyApplication.EnCode(infobean.getId_card()));
        indentify.setWork_sn(MyApplication.EnCode(infobean.getWork_sn()));
        indentify.setDepart_name(infobean.getDepart_name());
        indentify.setPrincipal_name(infobean.getPrincipal_name());
        indentify.setPerson_iris_sn(infobean.getPerson_iris_sn());
        indentify.setPhoto_flag(infobean.getPhoto_flag());

        indentify.setState(MyApplication.SUCCEED_STATE);
        indentify.setTime(Utils.getDateTime());
        indentify.setLong_time(Timetool.getTime(Utils.getDateTime()));
        return indentify;
    }
    private void initViewData(final CollectiveCardInfo collectiveCardInfo) {

        //save collectiveCard Logs
        save(collectiveCardInfo);
        //view set text data
        if (collectiveCardInfo != null) {
            enterIntoNumber.setText(collectiveCardInfo.getCollectivePersonInfo().size() + "");
            collectionCarderNumber.setText(collectiveCardInfo.getCarderNumber());
            Utils.playerVoice(this, 2);
            if (collectiveCardInfo.getCollectiveDateInfo().getDate_start() != null
                    && !collectiveCardInfo.getCollectiveDateInfo().getDate_start().equals("")
                    && collectiveCardInfo.getCollectiveDateInfo().getDate_end() != null
                    && !collectiveCardInfo.getCollectiveDateInfo().getDate_end().equals("")) {
                dateLy.setVisibility(View.VISIBLE);
                mydate.setText(collectiveCardInfo.getCollectiveDateInfo().getDate_start() + "---" + collectiveCardInfo.getCollectiveDateInfo().getDate_end());
                dateLy.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(collectiveCardInfo.getCollectiveTimeInfo()!=null &&collectiveCardInfo.getCollectiveTimeInfo().size()>0) {
                            getDialog(collectiveCardInfo.getCollectiveTimeInfo());
                        }
                    }
                });

            } else {
                dateLy.setVisibility(View.GONE);
            }

            //view set person data
            if (collectiveCardInfo.getCollectivePersonInfo() != null && collectiveCardInfo.getCollectivePersonInfo().size() > 0) {
                getPersonListAdapter(collectiveCardInfo);
            }
            //view set timelist data
            if (collectiveCardInfo.getCollectivePersonInfo() != null && collectiveCardInfo.getCollectiveTimeInfo().size() > 0) {
                getTimeListAdapter(collectiveCardInfo.getCollectiveTimeInfo());
            }


        }
    }

    private void getPersonListAdapter(final CollectiveCardInfo dataList) {
        adapter = new LvCommonAdapter<CollectivePersonInfo>(ShowCollectiveInfo_Activity.this, R.layout.collective_personlist_item, dataList.getCollectivePersonInfo()) {
            @Override
            public void convert(ViewHolder holder, int position,CollectivePersonInfo info) {
                String person_sn= info.getPerson_sn();
                if(person_sn!=null&&!person_sn.equals("")){
                    PersonInfo personInfo=   FileDataHelp.compareCard(MyApplication.PERSIN_INFO_FILE,person_sn);
                    holder.setText(R.id.id,(position+1)+".");
                    holder.setText(R.id.name,MyApplication.DeCode(personInfo.getName()));
                    if(personInfo.getSex()==0){
                        holder.setText(R.id.sex,R.string.man);
                    }else if(personInfo.getSex()==1){
                        holder.setText(R.id.sex,R.string.woman);
                    }else if (personInfo.getSex() == 3) {
                        holder.setText(R.id.sex,R.string.unknownGender);
                    }

                }


            }

        };


        personlist_view.setAdapter(adapter);
        ListUtil.setListViewHeightBasedOnChildren(personlist_view, 5);
        personlist_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String person_sn=  dataList.getCollectivePersonInfo().get(position).getPerson_sn();
                Intent intent = new Intent();
                intent.setClass(ShowCollectiveInfo_Activity.this, CollectivePageActivity.class);
                intent.putExtra("cardNumber",  dataList.getCarderNumber());
                startActivity(intent);
            }
        });
    }
    private void getTimeListAdapter(List<CollectiveCardAuthorizationTime> dataList) {
        adapter = new LvCommonAdapter<CollectiveCardAuthorizationTime>(ShowCollectiveInfo_Activity.this, R.layout.collective_timelist_item, dataList) {
            @Override
            public void convert(ViewHolder holder, int position,CollectiveCardAuthorizationTime timeInfo) {
                if(timeInfo.getStart_time()!=null&&!timeInfo.getStart_time().equals("")){
                    // holder.setText(R.id.id,(position+1)+".");
                    holder.setText(R.id.start_time,timeInfo.getStart_time());
                }
                if(timeInfo.getEnd_time()!=null&&!timeInfo.getEnd_time().equals("")){
                    holder.setText(R.id.end_time,timeInfo.getEnd_time());
                }
                if(timeInfo.getWeek_info()!=null&&!timeInfo.getWeek_info().equals("")){
                    holder.setText(R.id.auth_week,timeInfo.getWeek_info());
                }

            }

        };
        timeList_view.setAdapter(adapter);
        ListUtil.setListViewHeightBasedOnChildren(personlist_view, 5);
    }
    private void savePerson(CollectiveCardInfo collectiveInfo) {
        if(collectiveInfo!=null&&collectiveInfo.getCollectivePersonInfo().size()>0){
            for(int i=0;i<=collectiveInfo.getCollectivePersonInfo().size()-1;i++){
                CollectivePersonInfo in=	collectiveInfo.getCollectivePersonInfo().get(i);
                in.getPerson_sn();
                if(in.getPerson_sn()!=null&&!in.getPerson_sn().equals("")){
                    PersonInfo personInfo=   FileDataHelp.compareCard(MyApplication.PERSIN_INFO_FILE,in.getPerson_sn());
                }
            }

        }
    }

    public void save(CollectiveCardInfo info) {
        String devices="";

        if(Utils.getLocalIpAddress()==null){
            SharedPreferences preferences = MyApplication.getContext().getSharedPreferences("ServerSocket", Context.MODE_PRIVATE);
            if(!preferences.getString("ip","").equals("")){
                devices = preferences.getString("ip","");
            }else{
                devices = MyApplication.getIMEI();
            }
        }else{
            devices=Utils.getLocalIpAddress();
        }
        Resources res =getResources();
        String[] collectiveTex=res.getStringArray(R.array.collectiveArray);

        JSONObject jsonObject = new JSONObject();
        try {//记录集体卡识别成功日志       保存路径：本地path=MyApplication.PERSIN_IDENTIFY_FILE
            //                  格式：JSON格式字符串
            jsonObject.put("person_sn",collectiveTex[0]+info.getCarderNumber());//卡号=（集体卡:+卡号）                                            //collective carder number
            jsonObject.put("recog_time", Utils.getDateTime());//当前识别时间
            jsonObject.put("device_sn", devices);//当前识别设备                                                                     //this devices info
            jsonObject.put("recog_pattern", MyApplication.RECOG_PATTERN);//选择识别模式  2=智能卡                           //2=IC carder
            jsonObject.put("state", MyApplication.SUCCEED_STATE);//识别状态  成功=0, 失败=1                 //state is success=0
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String bb = jsonObject + "\n";//分行写入本地path文件，一条识别记录为一行，格式为JSON格式字符串
        byte[] mm = new byte[0];
        try {
            mm = bb.toString().getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(MyApplication.PERSIN_IDENTIFY_FILE, true);
            try {
                fos.write(mm);

                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }



    @Override
    protected void onResume() {
        super.onResume();

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent();
                intent.setClass(ShowCollectiveInfo_Activity.this, WelcomeActivity.class);
                startActivity(intent);
                finish();

            }
        }, 1000 * 10);
    }

    public void getDialog(List<CollectiveCardAuthorizationTime> timeList) {
        Dialog myDialog = null;
        if (myDialog == null) {
            myDialog = new AlertDialog.Builder(this).create();
        }
        Window window = myDialog.getWindow();
        window.setGravity(Gravity.BOTTOM);
        myDialog.setCanceledOnTouchOutside(true);
        myDialog.setCancelable(true);//true
        //  myDialog.setFinishOnTouchOutside(true);
        myDialog.show();
        WindowManager windowManager = getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        WindowManager.LayoutParams lp = myDialog.getWindow().getAttributes();
        if(MyApplication.GLOBAL_SCREEN_ORIENTATION_FLAG){
            lp.width = display.getWidth();
            lp.height = display.getHeight();
        }else{
            lp.width = display.getWidth();
            lp.height = display.getHeight() ;
        }
        lp.dimAmount =0f;
        myDialog.getWindow().setAttributes(lp);
        myDialog.getWindow().setContentView(R.layout.timelist_dialog);
        ListView   myTimelistView=(ListView)   myDialog.getWindow().findViewById(R.id.myTimelistView);

        getTimeListAdapter(timeList);
    }
}
