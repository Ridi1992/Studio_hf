package khdz.click.com.hf_handhelddevice.activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Timer;
import java.util.TimerTask;

import khdz.click.com.hf_handhelddevice.FileDataHelp;
import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.data.PersonIdentifyInfo;
import khdz.click.com.hf_handhelddevice.data.PersonInfo;
import khdz.click.com.hf_handhelddevice.db.DBService;
import khdz.click.com.hf_handhelddevice.tools.Timetool;
import khdz.click.com.hf_handhelddevice.tools.Utils;

import static khdz.click.com.hf_handhelddevice.activity.WelcomeActivity.FLAG_HOMEKEY_DISPATCHED;

public class UnknownCarderActivity extends Activity {
	private TextView showText;
	private Button btText;
	private DBService server;
	private String UID = "";
	private PersonIdentifyInfo unknownBean;
	private Timer timer;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED,
				FLAG_HOMEKEY_DISPATCHED);// Shielding home button
		setContentView(R.layout.unnown);
		initView();
		sendBroadcast_closeBackgroundActivity();
		server = new DBService(this);
		UID = getIntent().getStringExtra("uid");
		initdata();
		timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				Intent intent = new Intent();
				intent.setClass(UnknownCarderActivity.this,
						WelcomeActivity.class);
				startActivity(intent);
				finish();

			}
		}, 1000 * 2);

	}

	private void initdata() {
		if (UID.trim().equals("")) {
			showText.setText(R.string.readCard_fail);
			btText.setText(R.string.resert_carder);
			Utils.playerVoice(this, 1);
		} else if (UID.equals("NONE_PSAM")) {
			showText.setText(R.string.none_psam);
			btText.setText(R.string.cardslot);
			Utils.playerVoice(this, 3);// no psamCarder
		} else if (UID.equals("Data_invalid")) {
			showText.setText(R.string.readCard_fail);
			btText.setText(R.string.resert_carder);
			Utils.playerVoice(this, 1);
		} else if (UID.equals("CPU_DF_fail")) {
			showText.setText(R.string.readCard_fail);
			btText.setText(R.string.resert_carder);
			Utils.playerVoice(this, 1);// illegal
		} else if (UID.equals("Data_failure")) {
			showText.setText(R.string.readCard_fail);
			btText.setText(R.string.resert_carder);
			Utils.playerVoice(this, 1);
		} else if (UID.equals("CPU_RANDOM_fail")) {
			showText.setText(R.string.readCard_fail);
			btText.setText(R.string.resert_carder);
			Utils.playerVoice(this, 1);
		} else if (UID.equals("encrypting_fail")) {
			showText.setText(R.string.readCard_fail);
			btText.setText(R.string.resert_carder);
			Utils.playerVoice(this, 1);
		} else {
			showText.setText(R.string.identify_illegality);// identify fail !
			btText.setText(R.string.NotThrough_Auth);
			Utils.playerVoice(this, 4);//
			unknownBean = saveUnknownCarderData(UID);
			boolean insert = server.insertIdentifyData(unknownBean);
		}
		if (unknownBean != null && unknownBean.getPerson_sn() != null
				&& !unknownBean.getPerson_sn().equals("")) {
			save(unknownBean);
		}

	}

	private void sendBroadcast_closeBackgroundActivity() {
		// if compareCarder FAIL,sendBroadcast,close Background Activity
		Intent intent = new Intent();
		intent.setAction("closeBackgroundActivity");
		sendBroadcast(intent);

	}

	private void initView() {
		showText = (TextView) findViewById(R.id.text);
		btText = (Button) findViewById(R.id.myButton);
		btText.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				UnknownCarderActivity.this.finish();
			}
		});
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Utils.stopVoice(this);
	}

	private PersonIdentifyInfo saveUnknownCarderData(String uid) {
        //save Unknown data
    	 PersonIdentifyInfo unknownBean = new PersonIdentifyInfo();
    	 PersonInfo nativeInfobean = FileDataHelp.compareCard(MyApplication.PERSIN_INFO_FILE, UID);
        
    	if (nativeInfobean != null && nativeInfobean.getPerson_sn() != null && !nativeInfobean.getId_card().equals("") && nativeInfobean.getId_card().equals(UID)) {
        	unknownBean.setPerson_sn(nativeInfobean.getPerson_sn());
        	unknownBean.setName(MyApplication.EnCode(nativeInfobean.getName()));
        	unknownBean.setSex(nativeInfobean.getSex());
        	unknownBean.setId_card(MyApplication.EnCode(uid));
        	unknownBean.setWork_sn(nativeInfobean.getWork_sn());
        	unknownBean.setDepart_name(nativeInfobean.getDepart_name());
        	unknownBean.setPrincipal_name(nativeInfobean.getPrincipal_name());
        	unknownBean.setPerson_iris_sn(nativeInfobean.getPerson_iris_sn());
        	unknownBean.setPhoto_flag(nativeInfobean.getPhoto_flag());
        	unknownBean.setState(MyApplication.FILE_STATE);
        	unknownBean.setTime(Utils.getDateTime());
        	unknownBean.setLong_time(Timetool.getTime(Utils.getDateTime()));
        }
//        else{
//    	Resources res =getResources();
//    	String[] unknownData=res.getStringArray(R.array.unknownCardInfoArray);
//
//        unknownBean.setPerson_sn(unknownData[0]);
//        unknownBean.setName(MyApplication.EnCode(unknownData[1]));
//        unknownBean.setSex(3);
//        unknownBean.setId_card(MyApplication.EnCode(uid));
//        unknownBean.setWork_sn(MyApplication.EnCode(unknownData[2]));
//        unknownBean.setDepart_name(unknownData[3]);
//        unknownBean.setPrincipal_name(unknownData[4]);
//        unknownBean.setPerson_iris_sn(unknownData[5]);
//        unknownBean.setPhoto_flag(0);
//        unknownBean.setState(MyApplication.FILE_STATE);
//        unknownBean.setTime(Utils.getDateTime());
//        unknownBean.setLong_time(Timetool.getTime(Utils.getDateTime()));
//        }

        return unknownBean;
    }

	public void save(PersonIdentifyInfo unknownBean) {
		String devices = "";
		if (Utils.getLocalIpAddress() == null) {
			SharedPreferences preferences = MyApplication.getContext().getSharedPreferences("ServerSocket", Context.MODE_PRIVATE);
			if(!preferences.getString("ip","").equals("")){
				devices = preferences.getString("ip","");
			}else{
				devices = MyApplication.getIMEI();
			}

			// return;if not have ip address ,not save this devices info.
		} else {
			devices = Utils.getLocalIpAddress();
		}
		JSONObject jsonObject = new JSONObject();
		try {jsonObject.put("person_sn", unknownBean.getPerson_sn());
			jsonObject.put("recog_time", unknownBean.getTime());
			jsonObject.put("device_sn", devices);
			jsonObject.put("recog_pattern", MyApplication.RECOG_PATTERN);
			jsonObject.put("state", MyApplication.FILE_STATE);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		String bb = jsonObject + "\n";// ����д�뱾��path�ļ���һ��ʶ���¼Ϊһ�У���ʽΪJSON��ʽ�ַ���
		byte[] mm = new byte[0];
		try {
			mm = bb.toString().getBytes("UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		FileOutputStream fos = null;
		try {// save data at native File.
			fos = new FileOutputStream(MyApplication.PERSIN_IDENTIFY_FILE, true);
			try {
				fos.write(mm);

				fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
