package khdz.click.com.hf_handhelddevice.broadcase;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;


import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.activity.Socket_Activity;
import khdz.click.com.hf_handhelddevice.activity.WelcomeActivity;
import khdz.click.com.hf_handhelddevice.db.DBService;
import khdz.click.com.hf_handhelddevice.thread.MyClient;

/**
 * Created by Administrator on 2017/8/16.
 */

public class SocketReceiver     extends BroadcastReceiver {
    public static String MYACTION = "socketReceiverAction";
    public static  List<Activity> socket_ActivityContextList=new ArrayList<Activity>();
    public Socket_Activity.SocketHandler socketHandler;
    public Message msg;
    public Context context;
    @Override
    public void onReceive(Context context, Intent intent) {
    	 this.context=context;
        socketHandler=new Socket_Activity.SocketHandler();
        msg=new Message();
       
        String action = intent.getAction();
        if (action.equals(SocketReceiver.MYACTION)) {
            String name = intent.getStringExtra("name");
            if(name.equals("connected")){
                sengMassage( 0,  name);
            }else if(name.equals("connect")){
                Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        if(MyClient.socketList.size()==0 &&socket_ActivityContextList.size()>0){
                            getFinish();
                        }
                    }
                }, 1000 * 5);

            } else if(name.equals("fileType1")){
                sengMassage( 1,  name);
            }  else if(name.equals("fileType2")){
                sengMassage( 2,  name);
            }  else if(name.equals("fileType3")){
                sengMassage( 3,  name);
            }  else if(name.equals("fileType4")){
                sengMassage( 4,  name);
            }  else if(name.equals("fileType5")){
                sengMassage( 5,  name);
            }  else if(name.equals("beginSendData")){
                sengMassage( 6,  name);
            }  else if(name.equals("SendDataOver")){
                sengMassage( 7,  name);
            } else if(name.equals("IdentifyFileNotExists")){
                //IdentifyFileNotExists  ReadCard
                getFinish();
            } else if(name.equals("Exception")){
                getFinish();
            }else if(name.equals("deleteFile")){  //delete logdate file
                // End of upload log date ,open ReadCard
                File file=new File(MyApplication.PERSIN_IDENTIFY_FILE);
                if(!file.isDirectory()&& file.exists() ){
                    file.delete();
                    DBService server=new DBService(MyApplication.getContext());
                    server.deleteIdentifyInfoTable();
                    getFinish();
                }


            }

        }

    }
    private void sengMassage(int i, String name) {
        msg.what=i;
        Bundle bundle = new Bundle();
        bundle.putString("text1", name);
        msg.setData(bundle);
        socketHandler.handleMessage(msg);
    }
    public void getFinish() {
//        try {
//            if(MyClient.socketList.size()>0 ) {
//            	 for(Socket  socket:MyClient.socketList){
//            		 socket.close();
//                 }
//               // MyClient.client.close();
//            }
            if(socket_ActivityContextList.size()>0){
                for(Activity  context1:socket_ActivityContextList){
                    context1.finish();
                }
            }
            
            
        
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
    }
}





