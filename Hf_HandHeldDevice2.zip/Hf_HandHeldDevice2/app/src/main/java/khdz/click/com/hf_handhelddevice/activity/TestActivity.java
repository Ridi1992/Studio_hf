package khdz.click.com.hf_handhelddevice.activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.List;

import khdz.click.com.hf_handhelddevice.CompareCarder;
import khdz.click.com.hf_handhelddevice.FileDataHelp;
import khdz.click.com.hf_handhelddevice.MyApplication;
import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationDate;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardAuthorizationTime;
import khdz.click.com.hf_handhelddevice.data.CollectiveCardInfo;
import khdz.click.com.hf_handhelddevice.tools.Utils;

public class TestActivity extends BaseReadCarderActivity {


    TextView carderText;
    MyBroadcast myBroadcast;
    String activity="khdz.click.com.hf_handhelddevice.activity.TestActivity";
    private CompareCarder compareCarder=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ridi);
        compareCarder=new CompareCarder(context);
        carderText=(TextView)findViewById(R.id.carderText);
        carderText.setText("请插入psam卡，并把cpu卡放于设备后面。自动读取卡号。如未读取到，请切换页面继续读取。");

        myBroadcast=new MyBroadcast();
        IntentFilter filter = new IntentFilter();
        filter.addAction(activity);
        registerReceiver(myBroadcast, filter);
    }



    @Override
    protected void onResume() {
        super.onResume();
        BaseReadCarderActivity.subclassActivity=activity;
    }

    private class MyBroadcast extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            int	 cardNumber = intent.getIntExtra("carderNumber",0);
            if(cardNumber==0){
               String Tag= intent.getStringExtra("ReadCardFailTag");
                carderText.setText("Tag="+Tag);
                compareCardFail(context,Tag);
            }else{
                Utils.playerVoice(TestActivity.this, 6);
                comperCarder(cardNumber);
                carderText.setText("="+cardNumber);
            }
        }
    }

    private void comperCarder(int carderNumber) {
        String  UID = String.valueOf(carderNumber);
        if(!UID.equals("")){
            CollectiveCardInfo collectiveCardInfo= FileDataHelp.collectiveCard(MyApplication.COLLECTIVITY_INFO_FILE,UID );
            if(collectiveCardInfo!=null){
                CollectiveCardAuthorizationDate dateInfo=FileDataHelp.collectiveCardDate(MyApplication.COLLECTIVITY_AUTH9_FILE,collectiveCardInfo.getCollective_carder_id());
                List<CollectiveCardAuthorizationTime> timeList=FileDataHelp.collectiveCardTime(MyApplication.COLLECTIVITY_AUTH10_FILE,collectiveCardInfo.getCollective_carder_id());
                if(collectiveCardInfo.getCarderNumber()!=null&&dateInfo.getDate_start()!=null&&dateInfo.getDate_end()!=null){

                    collectiveCardInfo.setCollectiveDateInfo(dateInfo);
                    collectiveCardInfo.setCollectiveTimeInfo(timeList);
                    compareCarder.collectiveCarder(context,collectiveCardInfo,UID);

                }else{
                    compareCarder.personCarder( context,UID);
                }

            } else{
                compareCarder.personCarder( context,UID);
            }

        }else{
            compareCardFail(context,"");
        }

    }
    public  void compareCardFail(Context activity, String CardFailTag) {
        Intent intent = new Intent();
        intent.putExtra("uid", CardFailTag);
        intent.setClass(activity, UnknownCarderActivity.class);//UnknownCarderActivity
        activity.startActivity(intent);
    }
}
