package khdz.click.com.hf_handhelddevice;

import java.io.File;

import khdz.click.com.hf_handhelddevice.activity.Setting_Activity;
import khdz.click.com.hf_handhelddevice.activity.Socket_Activity;
import khdz.click.com.hf_handhelddevice.broadcase.BootBroadcastReceiver;
import khdz.click.com.hf_handhelddevice.broadcase.NetWork;
import khdz.click.com.hf_handhelddevice.tools.Utils;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.view.Display;
import android.view.WindowManager;

/**
 * Created by Administrator on 2017/6/15.
 */
public class MyApplication  extends Application {
    public static Context context;
    //  changed  screen orientation
    public static boolean GLOBAL_SCREEN_ORIENTATION_FLAG = true;
    //SerialPort  CMD
	public static String CPU_DF="00A40000022001";
	public static String CPU_RANDOM08 = "0084000008";
	public static String PSAM_GET_RESPOND="00c0000008";//08 read 8 bytes
    public static String PSAM_INTERNAL="0088000108";
	public static String CPU_EXITERNAL="0082000008";
	public static String CPU_READ_BINARY="00b0810008";//The short file descriptor reads, so set 81 and the highest bit set 1.
    //state
    public   String LogTag="KHDZ";
    public  static String succeedNumber="9000";
    public  static int  SUCCEED_STATE=0;
    public  static int  FILE_STATE=1;
    public  static int RECOG_PATTERN =2;
    //File path   p
    public static String LOCAL_FOLDERS;
    public static String PERSIN_INFO_FILE;
    public static String PHOTO_PATH;
    public static String PERSIN_IDENTIFY_FILE;
    public static String PERSIN_AUTH3_FILE;
    public static String PERSIN_AUTH4_FILE;
    public static String PERSIN_AUTH5_FILE;
    public static String COLLECTIVITY_INFO_FILE;
    public static String COLLECTIVITY_AUTH9_FILE;
    public static String COLLECTIVITY_AUTH10_FILE;
    public static Context getContext() {
        return context;
    }
    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
        netReceiver();
//        registerScreenActionReceiver();
        MakeAppDirectory();
    }
   
	private void MakeAppDirectory() {
//    	     if(Utils.getSDPath()!=null){//保存在系统目录下，设置文件夹隐藏 (.+名称)，卸载应用时删除
            // LOCAL_FOLDERS=Utils.getSDPath()+"/KHDZ_Device";//SDCard目录
    	     LOCAL_FOLDERS=Environment.getExternalStorageDirectory()+"/KHDZ_Device";//内部目录
             Utils.makeRootDirectory(LOCAL_FOLDERS);//新建文件夹
             PHOTO_PATH=LOCAL_FOLDERS+"/photo/";
             Utils.makeRootDirectory(PHOTO_PATH);//新建头像Photo文件夹       type=2
             PERSIN_INFO_FILE=LOCAL_FOLDERS+"/PersonRegesterData.txt";//注册人员信息 type=1
             PERSIN_IDENTIFY_FILE=LOCAL_FOLDERS+"/identify_data.txt";//本地识别记录
             PERSIN_AUTH3_FILE=LOCAL_FOLDERS+"/PersonDeviceInfo.txt";//注册人员设备信息 type=3
             PERSIN_AUTH4_FILE=LOCAL_FOLDERS+"/PersionAuthorizationDate.txt";//注册人员授权日期 type=4
             PERSIN_AUTH5_FILE=LOCAL_FOLDERS+"/PersionAuthorizationTime.txt";//注册人员授权时间 type=5
             COLLECTIVITY_INFO_FILE=LOCAL_FOLDERS+"/CollectiveCardInfo.txt";//集体卡注册信息 type=8
            //集体卡授权日期信息 type=9
             COLLECTIVITY_AUTH9_FILE=LOCAL_FOLDERS+"/CollectiveAuthorizationDate_.txt";
             //集体卡授权时间信息 type=10
             COLLECTIVITY_AUTH10_FILE=LOCAL_FOLDERS+"/CollectiveAuthorizationTime.txt";
            
	}
//    private void registerScreenActionReceiver(){  
//    	BootBroadcastReceiver receiver=new BootBroadcastReceiver();
//        final IntentFilter filter = new IntentFilter();  
//        filter.addAction(Intent.ACTION_SCREEN_OFF);  
//        filter.addAction(Intent.ACTION_SCREEN_ON);  
//        filter.addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
//        registerReceiver(receiver, filter);  
//    } 
	private void netReceiver() {
		NetWork.NetworkState= Utils.network(context) ;
         if( NetWork.NetworkState){
             SharedPreferences  preferences =context.getSharedPreferences("ServerSocket", Context.MODE_PRIVATE);
             String   serverIP = preferences.getString("ip", "");
            
             if(serverIP.equals("")){//first connected  serverIP="";
                 Intent myIntent = new Intent(context, Setting_Activity.class);
                 myIntent.putExtra("Tag", "net");
                 myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                 context.startActivity(myIntent);
             }else {
                 Intent myIntent = new Intent(context, Socket_Activity.class);
                 myIntent.putExtra("serverIP",serverIP);
                 myIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                 context.startActivity(myIntent);
             }
         }else{// Please open the network link..

            // Utils.showToast("The network is not linked...");
         }	
		
	}
	
    /**Data encryption
     *  Decrypt local data
     * @param strInput
     * @return
     */
    @SuppressLint("NewApi")
	public static String DeCode(String strInput) {
        String strMyBase64 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/";
        if (strInput==null || strInput.isEmpty()) {
            return strInput;
        }
        if (strInput.length() % 3 != 0) {
            return "DecodeError";
            // throw new Exception("Error! Not Encode String");
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < strInput.length(); i+=3) {

            int iHight6= strMyBase64.indexOf(strInput.charAt(i));
            int iMiddle6 = strMyBase64.indexOf(strInput.charAt(i+1));
            int iLow4  = strMyBase64.indexOf(strInput.charAt(i+2));

            char chadDecode = (char)((iHight6 << 10) + (iMiddle6 << 4) + iLow4);
            sb.append(chadDecode);
        }
        return sb.toString();
    }

    /**
     *Data decryption
     * @param strInput
     * @return
     */
    @SuppressLint("NewApi")
	public static String EnCode(String strInput) {
        String strMyBase64 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/";
        if (strInput==null || strInput.isEmpty()) {
            return strInput;
        }
        char[] ZipData = new char[3];
        StringBuilder sb = new StringBuilder();
        for (int i = 0;i< strInput.length();i++) {
            char iTemp = strInput.charAt(i);
            ZipData[0] = strMyBase64.charAt((iTemp >> 10));
            ZipData[1] = strMyBase64.charAt(  (iTemp & 1008) >> 4);
            ZipData[2] = strMyBase64.charAt((iTemp & 15));
            sb.append(ZipData);
        }
        return sb.toString();
    }



    /**Through the socket network link
     * Download the image of the registrar sent by the server
     * @param phothName
     * @return
     */
    public  static String getFileNameIsPhoto(String phothName){
        String  url="",nowPhothName="";
        File file = new File(PHOTO_PATH);
        boolean isbreak=false;
        if(file.isDirectory()) {
            File[] fileArray = file.listFiles();
            if (null != fileArray && 0 != fileArray.length) {
                for (int i = 0; i < fileArray.length; i++) {
                    if( !fileArray[i].isDirectory()) {
                        String fileName = fileArray[i].getName();
                            if(fileName.length()>4 &&(fileName.contains(".jpg") ||fileName.contains(".png") ) ){
                            if(fileName.contains(".jpg")){
                                nowPhothName= phothName+"_image.jpg";
                            }else if(fileName.contains(".png")){
                                nowPhothName= phothName+"_image.png";
                            }
                            if(fileName.equals(nowPhothName)){
                                isbreak=true;
                                url=PHOTO_PATH + fileName ;
                            }
                            }
                    }
                    if(isbreak){
                        break;
                    }
                }
            }
        }
             return url;
        }

    public static void deleteNativePhoto(String filePath) {
        File file = new File(filePath);
        if(!file.isDirectory() && file.exists()){
            file.delete();
        }
    }

    /**
     * getMacAddress
     * errorCode is 000000000000
     */
    public static String getMacAddress(Context context) {
        String macAddress = "000000000000";
        try {
            WifiManager wifiMgr = (WifiManager) context
                    .getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = (null == wifiMgr ? null : wifiMgr
                    .getConnectionInfo());
            if (null != info) {
                if (!TextUtils.isEmpty(info.getMacAddress()))
                    macAddress = info.getMacAddress().replace(":", "");
                else
                    return macAddress;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return macAddress;
        }
        return macAddress;
    }


    /**
     *   devices IMEI
     * @return
     */
    public static  String getIMEI() {
    String szImei;
    TelephonyManager TelephonyMgr = (TelephonyManager) context.getSystemService(TELEPHONY_SERVICE);
    szImei = TelephonyMgr.getDeviceId();
    return  szImei;
}
public  static String getDevicesName(){
    String  name="";
    SharedPreferences preferences =context.getSharedPreferences("devices", Context.MODE_PRIVATE);
     name = preferences.getString("name","" );//MyApplication.getMacAddress(context)
    if(name==null ||name.equals("")){
        name= MyApplication.getIMEI() ;
    }
    return  name;

}


}

