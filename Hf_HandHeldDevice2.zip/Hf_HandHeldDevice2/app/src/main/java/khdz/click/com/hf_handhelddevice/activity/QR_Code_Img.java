package khdz.click.com.hf_handhelddevice.activity;

import static khdz.click.com.hf_handhelddevice.activity.WelcomeActivity.FLAG_HOMEKEY_DISPATCHED;


import org.json.JSONException;
import org.json.JSONObject;

import khdz.click.com.hf_handhelddevice.R;
import khdz.click.com.hf_handhelddevice.tools.DES;
import android.app.Activity;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

public class QR_Code_Img extends Activity {
	private final static int SCANNIN_GREQUEST_CODE = 1;
	ImageView qrCodeImg;
	TextView title,text;
	String DES_str="",message="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 requestWindowFeature(Window.FEATURE_NO_TITLE);
	     getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
	     this.getWindow().setFlags(FLAG_HOMEKEY_DISPATCHED, FLAG_HOMEKEY_DISPATCHED);//Shielding home button
		  setContentView(R.layout.qr_carder_info);
		  initView();
		  Bundle bundle = getIntent().getExtras();
		  DES_str= bundle.getString("result");
		  try {
			  message=DES.decryptDES(DES_str, DES.key);
			if (!message.contains("http")) {
				String mm= message.replaceAll(";", "\n");
				 text.setText(mm) ;
				 qrCodeImg.setImageBitmap((Bitmap) getIntent().getParcelableExtra("bitmap"));
            }
		} catch (Exception e) {
			e.printStackTrace();
		}  
    
	}
	private void initView() {
		 qrCodeImg=(ImageView)findViewById(R.id.qr_code_img);
		// qrCodeImg.setLayoutParams(new LayoutParams(WelcomeActivity.screenWidth, WelcomeActivity.screenWidth/2));
		 title=(TextView)findViewById(R.id.title);
		 title.setText(R.string.scan_info);
		 text=(TextView)findViewById(R.id.text);
	}	
	
	
    
}
