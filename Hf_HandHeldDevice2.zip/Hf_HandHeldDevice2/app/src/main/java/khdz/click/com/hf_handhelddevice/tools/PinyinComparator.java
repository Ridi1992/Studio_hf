package khdz.click.com.hf_handhelddevice.tools;

import java.util.Comparator;

import khdz.click.com.hf_handhelddevice.data.PersonInfo;

/**
 * 
 * @author xiaanming
 *
 */
public class PinyinComparator implements Comparator<PersonInfo> {

	public int compare(PersonInfo o1, PersonInfo o2) {
		if (o1.getSortLetters().equals("@")
				|| o2.getSortLetters().equals("#")) {
			return -1;
		} else if (o1.getSortLetters().equals("#")
				|| o2.getSortLetters().equals("@")) {
			return 1;
		} else {
			return o1.getSortLetters().compareTo(o2.getSortLetters());
		}
	}

}
